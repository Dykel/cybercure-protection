<?php
$host     = "localhost"; // Database Host
$user     = "root"; // Database Username
$password = ""; // Database's user Password
$database = "ccure"; // Database Name
$prefix   = "ccure_"; // Database Prefix for the script tables

$connect = mysqli_connect($host, $user, $password, $database);

// Checking Connection
if (mysqli_connect_errno()) {
    echo "Failed to connect with MySQL: " . mysqli_connect_error();
}

mysqli_set_charset($connect, "utf8");

$client = "No";

$site_url             = "http://cybercure.ngrok.io";
$CYBERCURE_path = "http://cybercure.ngrok.io/cybercure";
?>