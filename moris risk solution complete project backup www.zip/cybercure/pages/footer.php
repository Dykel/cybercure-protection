      <footer>
        <div class="row">
          <div class="col-lg-12">
            
          </div>
        </div>
      </footer>
    
    </div>
	
  </body>
</html>