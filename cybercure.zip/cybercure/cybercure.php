<?php

/**
 * Plugin Name: Cybercure for  #RISK[Solutions]Maurice
 * Plugin URI: https://cybercure.ngrok.io
 * Description: Cybercure for  #RISK[Solutions]Maurice
 * Version: April 2017
 * Author: cybercure.ngrok.io
 * Author URI: https://cybercure.ngrok.io
 */

/*======================================================================*\
|| #################################################################### ||
|| #                This file is part of Cybercure                    # ||
|| #                          for  #RISK[Solutions]Maurice            # ||
|| # ---------------------------------------------------------------- # ||
|| #         Copyright © 2017 cybercure.ngrok.io. All Rights Reserved.# ||
|| #                                                                  # ||
|| # ----------     Cybercure IS AN OPENSOURCE SOFTWARE    ---------- # ||
|| # -------------------- https://cybercure.ngrok.io -------- ------- # ||
|| #################################################################### ||
\*======================================================================*/

if(!defined('ABSPATH')) exit('restricted access');


# Define constants
define('cybercure_security_WORDPRESS_PLUGIN_BASE_URL',   plugins_url('',  __FILE__ ));
define('cybercure_security_WORDPRESS_PLUGIN_BASE_PATH',  plugin_dir_path( __FILE__ ));
define('cybercure_security_WORDPRESS_PLUGIN_NAMESPACE',  'Cybercure');
define('cybercure_security_WORDPRESS_PLUGIN_VERSION',    '1.2.1');

/*
|--------------------------------------------------------------------------
| Start the autoloader
|--------------------------------------------------------------------------
|
| Write the important stuff into the session
|+
*/

require_once(ABSPATH . '/wp-admin/includes/template.php');

# We extend the WP_List_Table class, so we need to make sure that it's there
if(!class_exists('WP_List_Table')){
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

if(!function_exists('CybercureAutoload')){
    require_once(cybercure_security_WORDPRESS_PLUGIN_BASE_PATH . 'lib/Cybercure/Autoloader.php');
}

# Require our config for later use
require_once cybercure_security_WORDPRESS_PLUGIN_BASE_PATH . 'includes/config.inc.php';

# Setup class (used on plugin installation/uninstalling
use Cybercure\Cybercure\Setup;
$Setup = new Setup();

# Check if we need to update the database
# in case that the plugin just got updated
if (get_option(cybercure_security_WORDPRESS_PLUGIN_NAMESPACE) != cybercure_security_WORDPRESS_PLUGIN_VERSION) {
    eval(file_get_contents(cybercure_security_WORDPRESS_PLUGIN_BASE_PATH . 'updates/' . cybercure_security_WORDPRESS_PLUGIN_VERSION . '.txt'));
    update_option(cybercure_security_WORDPRESS_PLUGIN_NAMESPACE, cybercure_security_WORDPRESS_PLUGIN_VERSION);
}

# Start the protection features if the current
# connecting ip is not on the exclusion list
use Cybercure\Cybercure\Cybercure;
$Cybercure = new Cybercure();
if(array_search($_SERVER['REMOTE_ADDR'], $excludedFromProtection) === FALSE) {
    # Start the protection features if the current user
    # is not an admin
    add_action('plugins_loaded', array($Cybercure, 'start_protection'));
}

# Create the admin menu if we are a admin
use Cybercure\Cybercure\Admin\Admin;
$Admin = new Admin();



