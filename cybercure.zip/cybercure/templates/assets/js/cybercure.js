/*======================================================================*\
|| #################################################################### ||
|| #                This file is part of Cybercure                    # ||
|| #                          for  #RISK[Solutions]Maurice            # ||
|| # ---------------------------------------------------------------- # ||
|| #         Copyright © 2017 cybercure.ngrok.io. All Rights Reserved.# ||
|| #                                                                  # ||
|| # ----------     Cybercure IS AN OPENSOURCE SOFTWARE    ---------- # ||
|| # -------------------- https://cybercure.ngrok.io -------- ------- # ||
|| #################################################################### ||
\*======================================================================*/

(function( $ ) {
    "use strict";

    $(function() {

        // Initialize jQuery Tabs
        $("#tabs").tabs();
        $("#tabs-bans-ip-inner").tabs();
        $("#tabs-bans-country-inner").tabs();

        // Initialize jQuery Datepicker
        $( "#banned_until" ).datepicker({
            altField: "#banned_until",
            altFormat: "d MM yy",
            minDate: "+1"
        });

        // Turn checkboxes into switchButtons
        $(".switchButton").switchButton({
            on_label: 'On',
            off_label: 'Off'
        });

    });

}(jQuery));
