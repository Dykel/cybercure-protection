<?php
include "header.php";
?>
	  <div class="page-header">
        <div class="row">
          <div class="col-lg-12">
            <div class="bs-example">
              <div class="jumbotron">
                <center>
				<div class="well" style="background-color: #d9534f; color: white;">
                    <h2>The User-Agent header is missing from your HTTP Request</h2>
                </div>
                <p>Contactez le webmaster + 23059755252. Site Web protégé par Cybercure Security.</p>
				</center>
              </div>
            </div>
          </div>
        </div>
      </div>

<?php
include "footer.php";
?>